/**
 * Copy and content for the home page, lifted from the Figma frame
 * "Concept 4" (node `1518:1970`).
 *
 * Components take this through props — never by importing this file directly
 * (see obsidian/frontend/component-conventions.md → Data rules). Swap it for a
 * CMS payload later without touching a single component.
 */

export interface NavLink {
  label: string;
  href: string;
}

export interface CtaLink {
  label: string;
  href: string;
}

export interface SectionIntro {
  eyebrow: string;
  title: string;
  description: string;
}

export interface HeroContent extends SectionIntro {
  actions: readonly CtaLink[];
  /** Small proof line under the fold divider. */
  trustLine: string;
  /** Service chips floating over the scene. */
  serviceChips: readonly string[];
}

export interface WhyContent extends SectionIntro {
  actions: readonly CtaLink[];
  /** Images that stream after the cursor, oldest fading out. */
  trailImages: readonly string[];
}

export interface ServiceCard {
  index: string;
  title: string;
  /** Sub-services listed on the opening card. */
  items?: readonly string[];
  /** Full-bleed photo card. */
  image?: string;
  /** Tail card carries a "Discover" affordance. */
  cta?: string;
  variant: "lime" | "photo" | "brand";
}

export interface StatItem {
  value: string;
  label: string;
}

/** The About paragraph greys the clauses that aren't the point. */
export interface AboutFragment {
  text: string;
  muted: boolean;
}

export interface AboutContent {
  eyebrow: string;
  bannerImage: string;
  stats: readonly StatItem[];
  paragraph: readonly AboutFragment[];
  actions: readonly CtaLink[];
}

export interface TeamMember {
  name: string;
  role: string;
  image: string;
}

export interface SocialLink {
  label: string;
  href: string;
  icon: "instagram" | "facebook" | "linkedin" | "twitter";
}

/** Lime tail card closing the team rail (Figma node `1575:238`). */
export interface TeamMoreCard {
  title: string;
  cta: string;
  href: string;
}

export interface TeamContent {
  eyebrow: string;
  title: string;
  socials: readonly SocialLink[];
  members: readonly TeamMember[];
  more: TeamMoreCard;
}

export interface FormField {
  name: string;
  label: string;
  placeholder: string;
  type: "text" | "tel" | "textarea";
}

export interface ContactContent extends SectionIntro {
  formTitle: string;
  fields: readonly FormField[];
  consentLead: string;
  consentLinkLabel: string;
  consentTail: string;
  submitLabel: string;
}

export const SITE_NAV: readonly NavLink[] = [
  { label: "Home", href: "#hero" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Our team", href: "#team" },
];

export const HEADER_CTA: CtaLink = { label: "Contact Us", href: "#contact" };

export const BRAND_NAME = "Dantora";

export const HERO_CONTENT: HeroContent = {
  eyebrow: "About Dantora",
  title: "Medicine that starts with understanding you",
  description:
    "Advanced diagnostics, genetic screening and specialist care in one clinic — with results explained in language you actually understand.",
  actions: [
    { label: "Book a visit", href: "#contact" },
    { label: "Our services", href: "#services" },
  ],
  trustLine: "Trusted by 40,000+ patients since 2011",
  serviceChips: [
    "Health Check-ups",
    "Diagnostic Imaging",
    "Genetic Testing",
    "Laboratory",
    "Specialist Care",
  ],
};

export const WHY_CONTENT: WhyContent = {
  eyebrow: "Why Dantora",
  title: "One clinic, one record, one team behind you",
  description:
    "No referrals across town, no repeated tests. Your doctors share a single medical history and decide together.",
  actions: [
    { label: "Our doctors", href: "#team" },
    { label: "How we work", href: "#about" },
  ],
  trailImages: [
    "/assets/Why Dantora/01.png",
    "/assets/Why Dantora/02.png",
    "/assets/Why Dantora/03.png",
    "/assets/Why Dantora/04.png",
    "/assets/Why Dantora/05.png",
    "/assets/Why Dantora/06.png",
    "/assets/Why Dantora/07.png",
    "/assets/Why Dantora/08.png",
  ],
};

export const SERVICES_INTRO: SectionIntro = {
  eyebrow: "Our Services",
  title: "Everything your diagnosis needs, under one roof",
  description:
    "From a routine check-up to a full genomic panel — five directions that cover prevention, diagnosis and long-term care.",
};

export const SERVICE_CARDS: readonly ServiceCard[] = [
  {
    index: "01",
    title: "Preventive Health Check-ups",
    items: ["Men's health", "Women's health", "Executive check-up"],
    variant: "lime",
  },
  {
    index: "02",
    title: "Diagnostic Imaging",
    image: "/assets/Our Services/01.png",
    cta: "Discover",
    variant: "photo",
  },
  {
    index: "03",
    title: "Genetic Testing",
    cta: "Discover",
    variant: "brand",
  },
  {
    index: "04",
    title: "Laboratory",
    image: "/assets/Our Services/02.png",
    cta: "Discover",
    variant: "photo",
  },
  {
    index: "05",
    title: "Specialist Care",
    image: "/assets/Our Services/03.png",
    cta: "Discover",
    variant: "photo",
  },
];

export const ABOUT_CONTENT: AboutContent = {
  eyebrow: "About the clinic",
  // Extracted from Figma node 1546:163 — the wide theatre shot the mockup uses,
  // which was not among the supplied photo folders.
  bannerImage: "/assets/About/banner.png",
  stats: [
    { value: "98%", label: "Patient satisfaction" },
    { value: "24h", label: "Average lab turnaround" },
    { value: "60+", label: "Doctors and specialists" },
    { value: "15", label: "Years of practice" },
  ],
  paragraph: [
    { text: "Dantora is a 4,000 m² clinic built around a single idea:", muted: true },
    { text: " diagnosis and treatment should never be separated. ", muted: false },
    {
      text: "Imaging, laboratory and consulting rooms sit on the same floor, ",
      muted: true,
    },
    { text: "and every result reaches your doctor the same day.", muted: false },
  ],
  actions: [
    { label: "Book a consultation", href: "#contact" },
    { label: "Price list", href: "#services" },
  ],
};

export const TEAM_CONTENT: TeamContent = {
  eyebrow: "Our Team",
  title: "The doctors you'll actually see, every visit.",
  socials: [
    { label: "Instagram", href: "https://instagram.com", icon: "instagram" },
    { label: "Facebook", href: "https://facebook.com", icon: "facebook" },
    { label: "LinkedIn", href: "https://linkedin.com", icon: "linkedin" },
    { label: "X", href: "https://x.com", icon: "twitter" },
  ],
  // Order and roles follow the Figma rail (node 1558:409). Names are invented:
  // the mockup's captions put a woman's name on a man's portrait and vice
  // versa, so each name here matches the person actually pictured.
  members: [
    {
      name: "Carter Botosh",
      role: "Cardiologist",
      image: "/assets/Our Team/01.png",
    },
    {
      name: "Elena Marsh",
      role: "Radiologist",
      image: "/assets/Our Team/02.png",
    },
    {
      name: "Adrian Kohl",
      role: "Medical Geneticist",
      image: "/assets/Our Team/03.png",
    },
    {
      name: "Nils Vance",
      role: "Endocrinologist",
      image: "/assets/Our Team/04.png",
    },
    {
      name: "Petra Lindqvist",
      role: "Neurologist",
      image: "/assets/Our Team/05.png",
    },
  ],
  more: {
    title: "And other 60+ specialists",
    cta: "Explore all",
    href: "#contact",
  },
};

export const CONTACT_CONTENT: ContactContent = {
  eyebrow: "Get in touch",
  title: "Not sure which specialist you need? Ask us.",
  description:
    "Leave your details and a coordinator will call you back within one working hour to help you choose a doctor and a time.",
  formTitle: "Request a call back",
  fields: [
    { name: "name", label: "Your name", placeholder: "Name", type: "text" },
    { name: "phone", label: "Your phone", placeholder: "Phone", type: "tel" },
    {
      name: "message",
      label: "Your message",
      placeholder: "Message",
      type: "textarea",
    },
  ],
  consentLead: "By submitting, you agree to our ",
  consentLinkLabel: "Privacy Policy",
  consentTail: " and the processing of your personal data.",
  submitLabel: "Send Request",
};
